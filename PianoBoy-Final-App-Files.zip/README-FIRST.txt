PianoBoy — final Android project files

Project folder: android/
Launcher icon: android/app/src/main/res/mipmap-*/ic_launcher.png
App label: PianoBoy

Build on GitHub Actions:
1. Upload this ZIP to the PianoBoy repository as PianoBoy-UI-Upgrade.zip.
2. Ensure the repository's existing workflow extracts this archive and builds the
   Gradle project inside the android/ folder (settings.gradle is there).
3. Run Actions and download the PianoBoy-APK artifact.

Note: this package has been structurally checked, but it has not been compiled or
installed in this environment. A successful GitHub Actions build is still needed
to confirm the final APK.
