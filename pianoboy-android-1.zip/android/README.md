PianoBoy Android project (offline WebView app, follows device rotation).
Build the APK without installing anything: push this folder to a GitHub repo,
open Actions > Build APK > Run workflow, download "Keyroom-apk" (app-debug.apk).
Or open the folder in Android Studio and run Build > Build APK(s).
The instrument lives in app/src/main/assets/index.html.
